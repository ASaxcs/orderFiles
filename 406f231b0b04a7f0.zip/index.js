const TelegramBot = require("node-telegram-bot-api");
const axios = require("axios");
const fs = require("fs");
const express = require("express");
const FormData = require("form-data");

// ===========================
// CONFIG
// ===========================
const TOKEN = "8157959539:AAGNfH_okDLmA2YlIIvKO4dKIxNhASPYuTw";
const VNUM_API_KEY = "";
const OCR_API_KEY = "K87776088288957";
const CHANNEL_ID = "@informasichmslie";
const ADMIN_ID = "7940712410"; 
const ADMIN_USERNAME = "Sumarwa";

const bot = new TelegramBot(TOKEN, { polling: true });
const DB_FILE = "./orders.json";
let orders = fs.existsSync(DB_FILE) ? JSON.parse(fs.readFileSync(DB_FILE)) : [];

const app = express();
app.use(express.json());

// ===========================
// MODE MAINTENANCE
// ===========================
let maintenanceMode = false;

// ===========================
// Variabel global untuk pengurangan saldo
// ===========================
let pendingReduceSaldo = null; 

// ===========================
// Fungsi API 5SIM
// ===========================
async function fetchPrices() {
  try { 
    const res = await axios.get("https://5sim.net/v1/guest/prices"); 
    return res.data || {}; 
  } catch { return {}; }
}

async function getPrice(country, service, prices) {
  try {
    if (!prices[country] || !prices[country][service] || !prices[country][service].any) return null;
    return prices[country][service][service]?.price || prices[country][service].any.cost || null;
  } catch { return null; }
}

async function buyVirtualNumber(service, country) {
  try {
    const res = await axios.get(
      `https://5sim.net/v1/user/buy/activation/${country}/any/${service}`,
      { headers: { Authorization: `Bearer ${VNUM_API_KEY}` } }
    );
    if (res.data && res.data.phone && res.data.id) return res.data;
    return { error: "Nomor virtual gagal dibuat" };
  } catch (err) {
    return { error: err.response?.data || err.message };
  }
}

// ===========================
// Daftar layanan lengkap
// ===========================
const serviceList = [
  { text: "📲 WhatsApp", code: "wa" },
  { text: "💬 Telegram", code: "telegram" },
  { text: "🌐 Google", code: "google" },
  { text: "📸 Instagram", code: "instagram" },
  { text: "📘 Facebook", code: "facebook" },
  { text: "🐦 Twitter", code: "twitter" },
  { text: "🛒 Shopee", code: "shopee" },
  { text: "🛍️ Lazada", code: "lazada" },
  { text: "🛒 Tokopedia", code: "tokopedia" },
  { text: "📦 Bukalapak", code: "bukalapak" },
  { text: "💼 LinkedIn", code: "linkedin" },
  { text: "🎵 TikTok", code: "tiktok" },
  { text: "📧 Gmail", code: "gmail" },
  { text: "📹 Zoom", code: "zoom" },
  { text: "🛠️ Microsoft", code: "microsoft" },
  { text: "🛡️ ProtonMail", code: "protonmail" },
  { text: "🎮 Steam", code: "steam" },
  { text: "📺 Netflix", code: "netflix" },
  { text: "🎶 Spotify", code: "spotify" },
  { text: "💳 Paypal", code: "paypal" },
  { text: "🛍️ eBay", code: "ebay" }
];

// ===========================
// Tombol Menu Utama
// ===========================
function getMainMenuKeyboard(isAdmin = false) {
  const keyboard = [
    [
      { text: "📱 Beli Nomor", callback_data: "btn_buy_page_0" },
      { text: "💰 Deposit QRIS", callback_data: "btn_deposit" },
      { text: "💳 Cek Saldo", callback_data: "btn_check_saldo" }
    ],
    [
      { text: "📋 Cek Nomor", callback_data: "btn_check_all" },
      { text: "💡 Bantuan NOKOS", callback_data: "btn_nokos_help" }
    ],
    [
      { text: "📣 Broadcast", callback_data: "btn_broadcast_menu" },
      { text: "📡 ChannelCast", callback_data: "btn_channelcast_menu" }
    ],
    [
      { text: "🤖 AI CS", callback_data: "btn_ai_help" }
    ],
    [
      { text: "👤 Hubungi Admin", url: `https://t.me/${ADMIN_USERNAME}` }
    ]
  ];

  if (isAdmin) {
    // Tambahkan tombol admin ekstra
    keyboard.splice(2, 0, [
      { text: maintenanceMode ? "🛠️ Matikan Mode Off" : "🛠️ Aktifkan Mode Off", callback_data: "btn_toggle_maintenance" },
      { text: "💰 Tambah Saldo Pelanggan", callback_data: "btn_admin_add_saldo" },
      { text: "💸 Kurangi Saldo Pelanggan", callback_data: "btn_admin_reduce_saldo" }
    ]);
  }

  return keyboard;
}

// ===========================
// Fungsi Keyboard Layanan per Halaman
// ===========================
function getServicePageKeyboardWithSaldo(page = 0, country = "indonesia", prices = {}, userSaldo = 0) {
  const perPage = 4;
  const start = page * perPage;
  const end = start + perPage;
  const pageServices = serviceList.slice(start, end);

  const buttons = pageServices.map(s => {
    const priceUSD = prices[country]?.[s.code]?.any?.price || 0;
    const priceText = priceUSD ? ` - Rp${Math.round(priceUSD * 15000).toLocaleString()}` : " - N/A";
    return [{ text: `${s.text}${priceText}`, callback_data: `service_${s.code}` }];
  });

  const navButtons = [];
  if (start > 0) navButtons.push({ text: "⬅️ Prev", callback_data: `btn_buy_page_${page - 1}` });
  if (end < serviceList.length) navButtons.push({ text: "➡️ Next", callback_data: `btn_buy_page_${page + 1}` });
  if (navButtons.length) buttons.push(navButtons);

  buttons.push([{ text: `💳 Saldo: Rp${userSaldo.toLocaleString()}`, callback_data: "btn_check_saldo" }]);
  buttons.push([{ text: "🏠 Kembali ke Menu Utama", callback_data: "btn_back_main" }]);

  return { inline_keyboard: buttons };
}

// ===========================
// Tombol Pemilihan Negara Saat Beli Nomor
// ===========================
function getCountryKeyboard(service, saldoUser) {
  const countriesList = [
    { text: "🇮🇩 Indonesia", code: "indonesia" },
    { text: "🇲🇾 Malaysia", code: "malaysia" },
    { text: "🇹🇭 Thailand", code: "thailand" },
    { text: "🇸🇬 Singapore", code: "singapore" },
    { text: "🇻🇳 Vietnam", code: "vietnam" },
    { text: "🇵🇭 Filipina", code: "philippines" },
    { text: "🇮🇳 India", code: "india" },
    { text: "🇰🇷 Korea Selatan", code: "korea" },
    { text: "🇯🇵 Jepang", code: "japan" },
    { text: "🇨🇳 China", code: "china" },
    { text: "🇺🇸 Amerika Serikat", code: "usa" },
    { text: "🇬🇧 Inggris", code: "uk" },
    { text: "🇩🇪 Jerman", code: "germany" },
    { text: "🇫🇷 Perancis", code: "france" },
    { text: "🇮🇹 Italia", code: "italy" },
    { text: "🇷🇺 Rusia", code: "russia" },
    { text: "🇧🇷 Brasil", code: "brazil" },
    { text: "🇨🇦 Kanada", code: "canada" },
    { text: "🇦🇺 Australia", code: "australia" },
    { text: "🇿🇦 Afrika Selatan", code: "southafrica" },
    { text: "🇲🇽 Meksiko", code: "mexico" }
  ];

  const inline_keyboard = [];
  for (let i = 0; i < countriesList.length; i += 2) {
    const row = [];
    for (let j = i; j < i + 2 && j < countriesList.length; j++) {
      row.push({ text: countriesList[j].text, callback_data: `country_${countriesList[j].code}_${service}` });
    }
    inline_keyboard.push(row);
  }

  inline_keyboard.push([{ text: `💳 Saldo: Rp${saldoUser.toLocaleString()}`, callback_data: "btn_check_saldo" }]);
  inline_keyboard.push([{ text: "🏠 Kembali ke Menu Utama", callback_data: "btn_back_main" }]);

  return { inline_keyboard };
}

// ===========================
// Tombol Deposit Inline Preset
// ===========================
function getDepositKeyboard() {
  const depositOptions = [10000, 20000, 50000, 100000, 200000];
  const buttons = depositOptions.map(amount => [{ text: `💰 Rp${amount.toLocaleString()}`, callback_data: `deposit_${amount}` }]);
  buttons.push([{ text: "🏠 Kembali ke Menu Utama", callback_data: "btn_back_main" }]);
  return { inline_keyboard: buttons };
}

// ===========================
// Tombol Admin Tambah Saldo
// ===========================
function getAdminUserListKeyboard(page = 0) {
  const perPage = 5;
  const start = page * perPage;
  const end = start + perPage;
  const pageUsers = orders.slice(start, end);

  const buttons = pageUsers.map(u => [{ text: `${u.chat_id} - Saldo: Rp${(u.saldo||0).toLocaleString()}`, callback_data: `admin_addsaldo_${u.chat_id}` }]);

  const navButtons = [];
  if (start > 0) navButtons.push({ text: "⬅️ Prev", callback_data: `admin_user_page_${page - 1}` });
  if (end < orders.length) navButtons.push({ text: "➡️ Next", callback_data: `admin_user_page_${page + 1}` });
  if (navButtons.length) buttons.push(navButtons);

  buttons.push([{ text: "🏠 Kembali ke Menu Utama", callback_data: "btn_back_main" }]);
  return { inline_keyboard: buttons };
}

function getAdminDepositPresetKeyboard(targetChatId) {
  const depositOptions = [10000, 20000, 50000, 100000, 200000];
  const buttons = depositOptions.map(amount => [{ text: `💰 Rp${amount.toLocaleString()}`, callback_data: `admin_deposit_${targetChatId}_${amount}` }]);
  buttons.push([{ text: "🏠 Kembali ke Menu Utama", callback_data: "btn_back_main" }]);
  return { inline_keyboard: buttons };
}

// ===========================
// /start
// ===========================
bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id.toString();
  const photo = "https://files.catbox.moe/43qk85.jpg";

  if (!orders.some(o => o.chat_id === chatId)) {
    orders.push({ chat_id: chatId, system: "REGISTERED_USER", saldo: 0 });
    fs.writeFileSync(DB_FILE, JSON.stringify(orders, null, 2));
  }

  bot.sendPhoto(chatId, photo, {
    caption:
`✨ *Selamat Datang di Virtual Number Bot*  

🔹 Layanan aktivasi lengkap  
🔹 Proses cepat & otomatis  
🔹 Deposit QRIS tersedia  
🔹 Bantuan admin tersedia

Silakan pilih menu di bawah.`,
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: getMainMenuKeyboard(chatId === ADMIN_ID) }
  });
});

// ===========================
// CALLBACK QUERY
// ===========================
const lastMessageId = {}; // penyimpanan message_id

bot.on("callback_query", async (query) => {
  const chatId = query.message.chat.id.toString();
  const messageId = query.message.message_id;
  lastMessageId[chatId] = messageId;

  bot.answerCallbackQuery(query.id, { text: "Sedang diproses...", show_alert: false });

  try {
    const data = query.data;
    const prices = await fetchPrices();
    const user = orders.find(o => o.chat_id === chatId);
    const saldoUser = user?.saldo || 0;

    const checkSaldo = () => {
      if (saldoUser <= 0) {
        bot.sendMessage(chatId, "❌ Saldo Anda 0. Silakan deposit terlebih dahulu.");
        return false;
      }
      return true;
    };

    if (data === "btn_buy_page_0") {
      if (!checkSaldo()) return;
      if (!prices || Object.keys(prices).length === 0) {
        return bot.sendMessage(chatId, "Gagal mengambil data harga. Silakan coba lagi nanti.");
      }
      const page = 0;
      return bot.editMessageReplyMarkup(
        getServicePageKeyboardWithSaldo(page, "indonesia", prices, saldoUser),
        { chat_id: chatId, message_id: messageId }
      );
    }

    if (data === "btn_toggle_maintenance" && chatId === ADMIN_ID) {
      maintenanceMode = !maintenanceMode;
      return bot.editMessageReplyMarkup({ inline_keyboard: getMainMenuKeyboard(true) }, { chat_id: chatId, message_id: messageId });
    }

    if (data === "btn_admin_add_saldo" && chatId === ADMIN_ID) {
      return bot.editMessageReplyMarkup(getAdminUserListKeyboard(0), { chat_id: chatId, message_id: messageId });
    }

    if (data === "btn_admin_reduce_saldo" && chatId === ADMIN_ID) {
      return bot.editMessageReplyMarkup(getAdminUserListKeyboard(0), { chat_id: chatId, message_id: messageId });
    }

    if (data.startsWith("admin_user_page_") && chatId === ADMIN_ID) {
      const page = parseInt(data.split("_")[3]);
      return bot.editMessageReplyMarkup(getAdminUserListKeyboard(page), { chat_id: chatId, message_id: messageId });
    }

    if (data.startsWith("admin_addsaldo_") && chatId === ADMIN_ID) {
      const targetChatId = data.split("_")[2];
      // Tampilkan pesan minta jumlah saldo
      return bot.sendMessage(chatId, `Kirim jumlah saldo yang ingin ditambahkan ke user ${targetChatId} (dalam Rp):`, {
        reply_markup: {
          force_reply: true
        }
      }).then((sentMsg) => {
        // Simpan info target user dan message_id balasan
        pendingReduceSaldo = {
          chatId: chatId,
          targetChatId: targetChatId,
          messageId: sentMsg.message_id
        };
      });
    }

    if (data.startsWith("admin_deposit_") && chatId === ADMIN_ID) {
      const parts = data.split("_");
      const targetChatId = parts[2];
      const amount = parseInt(parts[3]);
      const targetUser = orders.find(o => o.chat_id === targetChatId);
      if (!targetUser) return bot.sendMessage(chatId, "❌ Chat ID pelanggan tidak ditemukan.");

      // MODIFIKASI UTAMA: Menambahkan saldo ke user lain
      targetUser.saldo = (targetUser.saldo || 0) + amount;
      fs.writeFileSync(DB_FILE, JSON.stringify(orders, null, 2));

      bot.sendMessage(chatId, `✅ Saldo berhasil ditambahkan ke Chat ID ${targetChatId}: Rp${amount.toLocaleString()}`);
      bot.sendMessage(targetChatId, `💰 Saldo Anda bertambah Rp${amount.toLocaleString()}. Total saldo: Rp${(targetUser.saldo).toLocaleString()}`);

      return bot.editMessageReplyMarkup(getAdminUserListKeyboard(0), { chat_id: chatId, message_id: messageId });
    }

    if (data === "btn_back_main") {
      return bot.editMessageReplyMarkup({ inline_keyboard: getMainMenuKeyboard(chatId === ADMIN_ID) }, { chat_id: chatId, message_id: messageId });
    }

    if (data === "btn_check_saldo") {
      return bot.sendMessage(chatId, `💰 Saldo Anda saat ini: Rp${saldoUser.toLocaleString()}`);
    }

    if (data === "btn_check_all") {
      const nomor = orders.filter(o => o.chat_id === chatId && o.phone)
                           .map(o => o.phone).join("\n") || "Belum ada nomor terdaftar";
      return bot.sendMessage(chatId, `📱 Nomor Anda saat ini:\n${nomor}`);
    }

    if (data === "btn_nokos_help") {
      return bot.sendMessage(chatId,
        `📌 *Bantuan Nokos*\n\n1. Cara membeli nomor: /beli\n2. Cara cek nomor: /cek\n3. Cara deposit: /deposit\n\nJika ada masalah, hubungi admin.`, 
        { parse_mode: 'Markdown' }
      );
    }

    if (data === "btn_ai_help") {
      return bot.sendMessage(chatId, "🤖 CS AI siap membantu Anda! Silakan ketik pertanyaan atau masalah terkait transaksi.");
    }

    if (data === "btn_broadcast_menu") {
      if (chatId !== ADMIN_ID) return bot.sendMessage(chatId, "❌ Anda bukan admin.");
      return bot.sendMessage(chatId, "📢 Kirim /broadcast <pesan> untuk broadcast ke semua user.");
    }

    if (data === "btn_channelcast_menu") {
      if (chatId !== ADMIN_ID) return bot.sendMessage(chatId, "❌ Anda bukan admin.");
      return bot.sendMessage(chatId, "📢 Kirim /channelcast <pesan> untuk broadcast ke channel.");
    }

    if (data === "btn_deposit") {
      return bot.sendMessage(chatId, "💳 Pilih nominal deposit:", { reply_markup: getDepositKeyboard() });
    }

    if (data.startsWith("deposit_")) {
      const amount = parseInt(data.split("_")[1]);
      if (!user) return;

      user.pendingDeposit = amount;
      fs.writeFileSync(DB_FILE, JSON.stringify(orders, null, 2));

      const qrisUrl = "https://files.catbox.moe/dly0n3.jpg"; // placeholder QR
      return bot.sendPhoto(chatId, qrisUrl, {
        caption: `💳 Silakan transfer Rp${amount.toLocaleString()} via QRIS dan kirimkan bukti transaksi di sini.\nPastikan nama toko adalah *JB MARKET STORE*.`,
        parse_mode: "Markdown"
      });
    }

    if (data.startsWith("btn_buy_page_")) {
      if (!checkSaldo()) return;
      const page = parseInt(data.split("_")[3]);
      return bot.editMessageReplyMarkup(getServicePageKeyboardWithSaldo(page, "indonesia", prices, saldoUser), { chat_id: chatId, message_id: messageId });
    }

    if (data.startsWith("service_")) {
      if (!checkSaldo()) return;
      const service = data.split("_")[1];
      return bot.sendMessage(chatId, "Pilih negara:", { reply_markup: getCountryKeyboard(service, saldoUser) });
    }

    if (data.startsWith("country_")) {
      if (!checkSaldo()) return;

      const parts = data.split("_");
      const country = parts[1];
      const service = parts.slice(2).join("_");

      // PERUBAHAN: Pastikan saldo minimal Rp5.000
      const userSaldo = user.saldo || 0;
      const priceUSD = await getPrice(country, service, prices) || 0;
      const priceRp = Math.round(priceUSD * 15000);

      if (userSaldo < 5000) {
        return bot.sendMessage(chatId, `❌ Saldo minimal Rp5.000 agar bisa memesan nomor. Saldo Anda saat ini: Rp${userSaldo.toLocaleString()}`);
      }

      if (userSaldo < priceRp) 
        return bot.sendMessage(chatId, `❌ Saldo tidak cukup. Harga: Rp${priceRp.toLocaleString()}, Saldo Anda: Rp${userSaldo.toLocaleString()}`);

      const vnum = await buyVirtualNumber(service, country);
      if (vnum.error) return bot.sendMessage(chatId, `❌ Gagal membeli nomor: ${vnum.error}`);

      user.saldo -= priceRp;
      orders.push({
        chat_id: chatId,
        service,
        country,
        order_id: vnum.id,
        phone: vnum.phone,
        status: "PAID",
        price: priceUSD
      });
      fs.writeFileSync(DB_FILE, JSON.stringify(orders, null, 2));

      // Kirim notifikasi ke admin
      const layanan = service + " - " + country;
      bot.sendMessage(ADMIN_ID, `📝 User ${chatId} memesan layanan: ${layanan}\nNomor: ${vnum.phone}\nOrder ID: ${vnum.id}`);

      bot.sendMessage(chatId,
        `✅ Nomor berhasil dibuat!\n📞 ${vnum.phone}\n🆔 Order ID: ${vnum.id}\n💵 Harga: US$${priceUSD} (~Rp${priceRp.toLocaleString()})\n💰 Saldo tersisa: Rp${user.saldo.toLocaleString()}`,
        { parse_mode: "Markdown" }
      );

      // Otomatis OTP
      (async () => {
        const cheerio = require("cheerio");
        try {
          const url = `https://example.com/otp?phone=${encodeURIComponent(vnum.phone)}`;
          const res = await axios.get(url);
          const $ = cheerio.load(res.data);
          const otp = $("span#otp").text() || $("div.otp-code").text();
          if (otp) bot.sendMessage(chatId, `🔑 Kode OTP untuk nomor ${vnum.phone}: ${otp.trim()}`);
        } catch {
          bot.sendMessage(chatId, `⚠️ Gagal mengambil kode OTP otomatis untuk nomor ${vnum.phone}. Silakan cek manual.`);
        }
      })();
    }

  } catch (err) {
    console.error(err);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat memproses permintaan.");
  }
});

// ===========================
// OCR Deposit Otomatis
// ===========================
bot.on("photo", async (msg) => {
  const chatId = msg.chat.id.toString();
  if (maintenanceMode && chatId !== ADMIN_ID) return bot.sendMessage(chatId, "⚠️ Bot sedang dalam mode maintenance.");

  const photoArray = msg.photo;
  const fileId = photoArray[photoArray.length - 1].file_id;

  try {
    const fileLink = await bot.getFileLink(fileId);
    const tempFile = `/tmp/${fileId}.jpg`;
    const writer = fs.createWriteStream(tempFile);
    const response = await axios({ url: fileLink, method: 'GET', responseType: 'stream' });
    response.data.pipe(writer);
    await new Promise(resolve => writer.on('finish', resolve));

    const formData = new FormData();
    formData.append("file", fs.createReadStream(tempFile));
    formData.append("apikey", OCR_API_KEY);
    formData.append("language", "eng");

    const res = await axios.post("https://api.ocr.space/parse/image", formData, { headers: formData.getHeaders() });
    const parsedText = res.data.ParsedResults[0].ParsedText || "";

    if (!/JB\s*MARKET\s*STORE/i.test(parsedText)) {
      return bot.sendMessage(chatId, "❌ Nama toko bukan JB MARKET STORE. Deposit dibatalkan.");
    }

    const match = parsedText.replace(/[^\d]/g,'').match(/\d+/);
    const depositAmount = match ? parseInt(match[0]) : null;

    if (!depositAmount || depositAmount <= 0) {
      return bot.sendMessage(chatId, "❌ Nominal tidak terdeteksi. Deposit dibatalkan.");
    }

    const user = orders.find(o => o.chat_id === chatId);
    if (user) {
      user.saldo = (user.saldo || 0) + depositAmount;
      fs.writeFileSync(DB_FILE, JSON.stringify(orders, null, 2));
      bot.sendMessage(chatId, `✅ Deposit berhasil. Saldo bertambah Rp${depositAmount.toLocaleString()}. Total saldo: Rp${user.saldo.toLocaleString()}`);
    }

    fs.unlink(tempFile, () => {});

  } catch (err) {
    console.log("OCR Error:", err.message || err);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat membaca bukti deposit. Silakan coba lagi.");
  }
});

// ===========================
// AI CS
// ===========================
bot.onText(/(.+)/, async (msg, match) => {
  const chatId = msg.chat.id.toString();
  if (maintenanceMode && chatId !== ADMIN_ID) return bot.sendMessage(chatId, "⚠️ Bot sedang dalam mode maintenance.");

  const text = match[1];
  if (orders.some(o => o.chat_id === chatId) && text && text.length < 500) {
    const reply = `🤖 AI CS: Terima kasih pertanyaan Anda. Kami menerima pesan:\n"${text}"\nAdmin akan menindaklanjuti atau Anda bisa menunggu jawaban otomatis.`;
    bot.sendMessage(chatId, reply);
  }
});

// ===========================
// /broadcast & /channelcast
// ===========================
bot.onText(/\/broadcast (.+)/, async (msg, match) => {
  if (msg.chat.id.toString() !== ADMIN_ID) return bot.sendMessage(msg.chat.id, "❌ Anda bukan admin.");
  const text = match[1];
  const users = [...new Set(orders.map(o => o.chat_id))];

  const sentUsers = [];
  for (const u of users) {
    try {
      await bot.sendMessage(u, `📢 *Broadcast:*\n\n${text}`, { parse_mode: "Markdown" });
      sentUsers.push(u);
    } catch {}
  }
  const userListStr = sentUsers.length > 0 ? sentUsers.join(", ") : "Tidak ada user yang menerima broadcast.";
  bot.sendMessage(msg.chat.id, `✅ Broadcast terkirim ke user: ${userListStr}`);
});

bot.onText(/\/channelcast (.+)/, async (msg, match) => {
  if (msg.chat.id.toString() !== ADMIN_ID) return bot.sendMessage(msg.chat.id, "❌ Anda bukan admin.");
  try { 
    await bot.sendMessage(CHANNEL_ID, `📢 *ChannelCast:*\n\n${match[1]}`, { parse_mode: "Markdown" }); 
    bot.sendMessage(msg.chat.id, "✅ Berhasil terkirim ke channel."); 
  } catch { 
    bot.sendMessage(msg.chat.id, "❌ Gagal mengirim ke channel."); 
  }
});

// ===========================
// /status <orderId>
// ===========================
bot.onText(/\/status (.+)/, (msg, match) => {
  const orderId = match[1];
  const order = orders.find(o => o.order_id === orderId);
  if (!order) return bot.sendMessage(msg.chat.id, "❌ Order ID tidak ditemukan.");
  bot.sendMessage(msg.chat.id, `📞 Nomor: ${order.phone}\n🆔 Order ID: ${order.order_id}\n💵 Harga: US$${order.price || 0}`);
});

// ===========================
// Server
// ===========================
app.listen(3000, () => console.log("Server running on port 3000"));

// ===========================
// Handler pesan untuk pengurangan saldo
// ===========================
bot.on("message", (msg) => {
  const chatId = msg.chat.id.toString();

  if (pendingReduceSaldo && chatId === pendingReduceSaldo.chatId && msg.reply_to_message && msg.reply_to_message.message_id === pendingReduceSaldo.messageId) {
    const amount = parseInt(msg.text);
    if (isNaN(amount) || amount <= 0) {
      bot.sendMessage(chatId, "Jumlah tidak valid. Pengurangan dibatalkan.");
      pendingReduceSaldo = null;
      return;
    }

    // Kurangi saldo user
    const user = orders.find(o => o.chat_id === pendingReduceSaldo.targetChatId);
    if (user) {
      user.saldo = (user.saldo || 0) - amount;
      if (user.saldo < 0) user.saldo = 0; // Tidak boleh negatif
      fs.writeFileSync(DB_FILE, JSON.stringify(orders, null, 2));
      bot.sendMessage(chatId, `Saldo user ${pendingReduceSaldo.targetChatId} berhasil dikurangi Rp${amount.toLocaleString()}. Saldo baru: Rp${(user.saldo).toLocaleString()}`);
      bot.sendMessage(pendingReduceSaldo.targetChatId, `Saldo Anda dikurangi Rp${amount.toLocaleString()}. Saldo sekarang: Rp${(user.saldo).toLocaleString()}`);
    } else {
      bot.sendMessage(chatId, "User tidak ditemukan.");
    }
    pendingReduceSaldo = null;
  }
});